﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameRecommendationConsoleApp.DataStructures
{
    public class GameRating
    {
        [LoadColumn(0)]
        public double userId;

        [LoadColumn(2)]
        public double gameId;

        [LoadColumn(4)]
        public float Label;
    }
}
