﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace GameRecommendationConsoleApp.DataStructures
{
    public class GenreRating
    {
        [LoadColumn(0)]
        public double userId;

        [LoadColumn(3)]
        public string genre;

        [LoadColumn(4)]
        public float Label;
    }
}
