﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using GameRecommendation; 

namespace GameRecommendation.DataStructures
{
    class Game
    {
        public int gameId;
        public String gameTitle;

        public String gameGenre;

        private static string gamesdatasetpath = Path.Combine(Environment.CurrentDirectory, "Data", "JustGames.csv");

        public Lazy<List<Game>> _games = new Lazy<List<Game>>(() => LoadGameData(gamesdatasetpath));
        
        public Game()
        {
        }

        public Game Get(int id)
        {
            return _games.Value.Single(m => m.gameId == id);
        }


        private static List<Game> LoadGameData(String gamesdatasetpath)
        {
            var result = new List<Game>();
            Stream fileReader = File.OpenRead(gamesdatasetpath);
            StreamReader reader = new StreamReader(fileReader);
            try
            {
                bool header = true;
                int index = 0;
                var line = "";
                while (!reader.EndOfStream)
                {
                    if (header)
                    {
                        line = reader.ReadLine();
                        header = false;
                    }
                    line = reader.ReadLine();
                    string[] fields = line.Split(',');
                    int gameId = Int32.Parse(fields[0].ToString().TrimStart(new char[] { '0' }));
                    string gameTitle = fields[1].ToString();
                    string gameGenre = fields[2].ToString();
                    if(!Program.IDsCreated)
                    {
                        Program.allIDs.Add(gameId);
                        if (!Program.allGenres.Contains(gameGenre))
                        {
                            Program.allGenres.Add(gameGenre);
                        }
                            
                    }
                    result.Add(new Game() { gameId = gameId, gameTitle = gameTitle, gameGenre = gameGenre});
                    index++;
                }
                Program.IDsCreated = true;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Dispose();
                }
            }

            return result;
        }
    }
}
