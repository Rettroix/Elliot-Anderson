﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameRecommendationConsoleApp.DataStructures
{
    class GameRatingPrediction
    {
        public float Label;

        public float Score;
    }
}
