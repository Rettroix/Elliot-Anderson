﻿using System;
using Microsoft.ML;
using GameRecommendationConsoleApp.DataStructures;
using GameRecommendation.DataStructures;
using System.IO;
using Microsoft.ML.Trainers;
using System.Collections.Generic;
namespace GameRecommendation
{
    class Program
    {
        public static bool IDsCreated = false;
        public static List<int> allIDs = new List<int>();
        public static List<string> allGenres = new List<string>();

        private static string TrainingDataLocation = Path.Combine(Environment.CurrentDirectory, "Data"
            , "Steam-train.csv");
        private static string TestDataLocation = Path.Combine(Environment.CurrentDirectory, "Data"
            , "Steam-test.csv");

        private const float predictionuserId = 2;
        private const int predictiongameId = 10;

        static void Main(string[] args)
        {
            //initializing mlContext creates a new ML.NET environment that can 
            //be shared across the model creation workflow objects. 
            MLContext mlcontext = new MLContext();
            TrainGameModel(mlcontext);
            
            Console.WriteLine("=============== End of process, hit any key to finish ===============");
            Console.ReadLine();
        }

        public static void TrainGameModel(MLContext mlcontext)
        {


            //Read the training data which will be used to train the game recommendation model    
            //The schema for training data is defined by type 'TInput' in LoadFromTextFile<TInput>() method.
            IDataView trainingDataView = mlcontext.Data.LoadFromTextFile<GameRating>(TrainingDataLocation, 
                hasHeader: true, separatorChar: ',');

            //Transform your data by encoding the two features userId and gameId. These encoded features will be provided as input
            //to our MatrixFactorizationTrainer.
            var dataProcessingPipeline = mlcontext.Transforms.Conversion.MapValueToKey(outputColumnName: 
                "userIdEncoded", inputColumnName: nameof(GameRating.userId))
                           .Append(mlcontext.Transforms.Conversion.MapValueToKey(outputColumnName: 
                           "gameIdEncoded", inputColumnName: nameof(GameRating.gameId)));

            //Specify the options for MatrixFactorization trainer            
            MatrixFactorizationTrainer.Options options = new MatrixFactorizationTrainer.Options();
            options.MatrixColumnIndexColumnName = "userIdEncoded";
            options.MatrixRowIndexColumnName = "gameIdEncoded";
            options.LabelColumnName = "Label";
            options.NumberOfIterations = 500;
            options.ApproximationRank = 100;

            //Create the training pipeline 
            var trainingPipeLine = dataProcessingPipeline.Append(mlcontext.Recommendation().Trainers
                .MatrixFactorization(options));

            //Train the model fitting to the DataSet
            Console.WriteLine("=============== Training the model ===============");
            ITransformer model = trainingPipeLine.Fit(trainingDataView);

            //Evaluate the model performance 
            Console.WriteLine("=============== Evaluating the model ===============");
            IDataView testDataView = mlcontext.Data.LoadFromTextFile<GameRating>(TestDataLocation, 
                hasHeader: true, separatorChar: ',');
            var prediction = model.Transform(testDataView);
            var metrics = mlcontext.Regression.Evaluate(prediction, labelColumnName: "Label", 
                scoreColumnName: "Score");
            Console.WriteLine("The model evaluation metrics RootMeanSquaredError:" 
                + metrics.RootMeanSquaredError);
            Console.WriteLine("RSquared: " + metrics.RSquared.ToString());
            SaveModel(mlcontext, trainingDataView.Schema, model);
            UseModelForSinglePrediction(mlcontext, model);
            UseModelForMultiplePredictions(mlcontext, model);
        }

        public static string TrainGenreModel(MLContext mlcontext, Double userID)
        {
            //Read the training data which will be used to train the game recommendation model    
            //The schema for training data is defined by type 'TInput' in LoadFromTextFile<TInput>() method.
            IDataView trainingDataView = mlcontext.Data.LoadFromTextFile<GenreRating>(TrainingDataLocation
                , hasHeader: true, separatorChar: ',');

            //Transform your data by encoding the two features userId and gameId. These encoded features will be provided as input
            // to our MatrixFactorizationTrainer.
            var dataProcessingPipeline = mlcontext.Transforms.Conversion.MapValueToKey(outputColumnName: 
                "userIdEncoded", inputColumnName: nameof(GenreRating.userId))
                           .Append(mlcontext.Transforms.Conversion.MapValueToKey(outputColumnName: 
                           "genreEncoded", inputColumnName: nameof(GenreRating.genre)));

            //Specify the options for MatrixFactorization trainer            
            MatrixFactorizationTrainer.Options options = new MatrixFactorizationTrainer.Options();
            options.MatrixColumnIndexColumnName = "userIdEncoded";
            options.MatrixRowIndexColumnName = "genreEncoded";
            options.LabelColumnName = "Label";
            options.NumberOfIterations = 1000;
            options.ApproximationRank = 100;

            //Create the training pipeline 
            var trainingPipeLine = dataProcessingPipeline.Append(mlcontext.Recommendation().Trainers
                .MatrixFactorization(options));

            //Train the model fitting to the DataSet
            Console.WriteLine("=============== Training the model ===============");
            ITransformer model = trainingPipeLine.Fit(trainingDataView);

            //Evaluate the model performance 
            Console.WriteLine("=============== Evaluating the model ===============");
            IDataView testDataView = mlcontext.Data.LoadFromTextFile<GenreRating>(TestDataLocation, 
                hasHeader: true, separatorChar: ',');
            var prediction = model.Transform(testDataView);
            var metrics = mlcontext.Regression.Evaluate(prediction, labelColumnName: "Label", 
                scoreColumnName: "Score");
            Console.WriteLine("The model evaluation metrics RootMeanSquaredError:" 
                + metrics.RootMeanSquaredError);
            Console.WriteLine("RSquared: " + metrics.RSquared.ToString());

            //SaveModel(mlcontext, trainingDataView.Schema, model);

            return FindUsersFavGenre(mlcontext, model, userID);
        }

        public static void UseModelForSinglePrediction(MLContext mlContext, ITransformer model)
        {
            Game gameService = new Game();

            Console.WriteLine("=============== Making a prediction ===============");
            var predictionEngine = mlContext.Model.CreatePredictionEngine<GameRating
                , GameRatingPrediction>(model);

            var testInput = new GameRating { userId = 119428254, gameId = 10};

            var gameRatingPrediction = predictionEngine.Predict(testInput);


            if (Math.Round(gameRatingPrediction.Score, 1) > 3.5)
            {
                Console.WriteLine("Game " + gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle  
                    + " is recommended for user " + testInput.userId);
            }
            else
            {
                Console.WriteLine("Game " + gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle 
                    + " is not recommended for user " + testInput.userId);
            }

            Console.WriteLine(allIDs[3]);
            Console.WriteLine(allGenres[3]);
            Console.WriteLine(allGenres.Count);

        }

        public static void UseModelForMultiplePredictions(MLContext mlContext, ITransformer model)
        {
            Game gameService = new Game();
            
            Console.WriteLine("=============== Enter your user ID ===============");
            Double userID = Double.Parse(Console.ReadLine());
            var predictionEngine = mlContext.Model.CreatePredictionEngine<GameRating, 
                GameRatingPrediction>(model);
            Random rnd = new Random();
            List<string> games = new List<string>();
            string usersFavGenre = TrainGenreModel(mlContext, userID);
            Console.WriteLine();
            Console.WriteLine("We predict you enjoy games in this genre: " + usersFavGenre 
                + " therefore we think you will like these games...");
            Console.WriteLine();
            for (int i = 0; i < 5; i++)
            {

                var testInput = new GameRating { userId = userID, gameId = allIDs[rnd.Next(allIDs.Count - 1)]};
                var gameRatingPrediction = predictionEngine.Predict(testInput);

                while (Math.Round(gameRatingPrediction.Score, 1) < 10 
                    || gameService.Get(Convert.ToInt32(testInput.gameId)).gameGenre != usersFavGenre 
                    || games.Contains(gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle))
                {
                    testInput = new GameRating { userId = userID, gameId = allIDs[rnd.Next(allIDs.Count - 1)] };
                    gameRatingPrediction = predictionEngine.Predict(testInput);
                }

                if (Math.Round(gameRatingPrediction.Score, 1) > 3.5)
                {
                    games.Add(gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle);
                    Console.WriteLine("Game " + gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle 
                        + " is recommended for user " + testInput.userId 
                        + " because they are likely to play this game for " 
                        + Math.Round(gameRatingPrediction.Score, 1) + " hours." 
                        + " The game's genre is: " + gameService.Get(Convert.ToInt32(testInput.gameId))
                        .gameGenre);
                }

            }
            Console.WriteLine();
            Console.WriteLine("We also think you may enjoy these other games of different genres: ");
            Console.WriteLine();
            for (int i = 0; i < 10; i++)
            {

                var testInput = new GameRating { userId = userID, gameId = allIDs[rnd.Next(allIDs.Count - 1)] };
                var gameRatingPrediction = predictionEngine.Predict(testInput);

                while (Math.Round(gameRatingPrediction.Score, 1) < 10 
                    ||  games.Contains(gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle))
                {
                    testInput = new GameRating { userId = userID, gameId = allIDs[rnd.Next(allIDs.Count - 1)] };
                    gameRatingPrediction = predictionEngine.Predict(testInput);
                }

                if (Math.Round(gameRatingPrediction.Score, 1) > 3.5)
                {
                    games.Add(gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle);
                    Console.WriteLine("Game " + gameService.Get(Convert.ToInt32(testInput.gameId)).gameTitle 
                        + " is recommended for user " + testInput.userId 
                        + " because they are likely to play this game for " 
                        + Math.Round(gameRatingPrediction.Score, 1) + " hours." 
                        + " The game's genre is: "
                        + gameService.Get(Convert.ToInt32(testInput.gameId)).gameGenre);
                }

            }
        }

        public static string FindUsersFavGenre(MLContext mlContext, ITransformer model, Double userID)
        {
            Game gameService = new Game();

            var predictionEngine = mlContext.Model.CreatePredictionEngine<GenreRating
                , GameRatingPrediction>(model);
            float highestScore = 0;
            string usersFavGenre = "NULL";
            for (int i = 0; i < allGenres.Count; i++)
            {

                var testInput = new GenreRating { userId = userID, genre = allGenres[i] };
                var genreRatingPrediction = predictionEngine.Predict(testInput);

                if(genreRatingPrediction.Score > highestScore)
                {
                    highestScore = genreRatingPrediction.Score;
                    usersFavGenre = testInput.genre;
                }

            }
            Console.WriteLine("User " + userID + " predicted favourite genre is " 
                + usersFavGenre + " it's score is: " + highestScore);

            return usersFavGenre;
        }

        public static void SaveModel(MLContext mlContext, DataViewSchema trainingDataViewSchema
            , ITransformer model)
        {
            var modelPath = Path.Combine(Environment.CurrentDirectory, "Data", "gameRecommenderModel.zip");

            Console.WriteLine("=============== Saving the model to a file ===============");
            mlContext.Model.Save(model, trainingDataViewSchema, modelPath);
        }

    }
}
